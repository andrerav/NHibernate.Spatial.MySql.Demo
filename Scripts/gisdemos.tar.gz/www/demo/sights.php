<?php

// Get bounding box
$bbox = $_GET['bbox']; // get the bbox param from google earth
list($bbox_west, $bbox_south, $bbox_east, $bbox_north) = split(",", $bbox); // west, south, east, north
if (!$bbox_south)
{
  $bbox_south = -90;
  $bbox_west = -180;
  $bbox_east = 180;
  $bbox_north = 90;
}

// Connection details
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'demo';

$bbox_clause = "WHERE ST_Within(pos, ST_MakeEnvelope(Point($bbox_west, $bbox_south), Point($bbox_east, $bbox_north)))";

$query = "SELECT JSON_APPEND(JSON_APPEND('{\"type\":\"Feature\"}', 'geometry', ST_AsGeoJSON(pos)), 'properties', JSON_APPEND('{}', 'description', CONCAT('\"', description, '\"'))) AS json FROM sights $bbox_clause GROUP BY id";

// Connect and run query
if (!($conn = new mysqli($servername, $username, $password, $database)) ||
    mysqli_connect_errno() ||
    !($stmt = $conn->prepare($query)) ||
    !($stmt->execute()) ||
    !($stmt->bind_result($geojson)) ||
    !($stmt->fetch()))
{
  print "Whoops! $conn->errno $conn->error\n";
}

// Print FeatureCollection header
print '{"type":"FeatureCollection","features":[';

print $geojson;

$num_sights = 1;
while ($stmt->fetch()) {
  print ",$geojson";
  $num_sights++;
}

print ']}';

$stmt->close();
$conn->close();

// Dump some debug info in log.html
ob_start();
print '<html><head></head><body><pre>';
print '$bbox = '; var_dump($bbox);
print 'bbox_south: '; var_dump($bbox_south);
print 'bbox_west: '; var_dump($bbox_west);
print 'bbox_east: '; var_dump($bbox_east);
print 'bbox_north: '; var_dump($bbox_north);
print '$num_sights = '; var_dump($num_sights);
print '$bbox_clause = '; var_dump($bbox_clause);
print '$query = '; var_dump($query);
print '</pre></body></html>';
file_put_contents('log.html', ob_get_contents());
ob_end_clean();

?>

