USE demo;

CREATE TABLE sights (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pos POINT NOT NULL,
  description VARCHAR(200)
) ENGINE=InnoDB;

INSERT INTO sights (pos, description) VALUES (
  Point(10.3958, 63.4269),
  'Nidaros Cathedral'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromGeoJSON('{"type":"Point","coordinates":[10.4025,63.4194]}'),
  'Norwegian University of Science and Technology'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3948 63.4225)', 4326),
  'Student Society Building'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3951 63.4305)'),
  'Olav Tryggvason Monument'
);

UPDATE sights SET pos = ST_GeomFromWKB(ST_AsBinary(pos));

ALTER TABLE sights ADD SPATIAL INDEX (pos);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4017 63.4282)'),
  'Old Town Bridge'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3830 63.4510)'),
  'Munkholmen'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3930 63.4339)'),
  'Boat to Munkholmen'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3960 63.4261)'),
  'Archbishop\'s Palace'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3952 63.4261)'),
  'Crown Jewels'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4106 63.4269)'),
  'Kristiansten Fortress'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4523 63.4483)'),
  'Ringve Botanical Gardens'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4546 63.4474)'),
  'Ringve Museum'
); 

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.3783 63.4301)'),
  'Norwegian National Museum of Justice'
); 

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4320 63.4224)'),
  'Tyholt Tower'
); 

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4013 63.4389)'),
  'Rockheim - Museum of Pop and Rock'
); 

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4031 63.42803)'),
  'Bicycle Lift'
);

INSERT INTO sights (pos, description) VALUES (
  ST_GeomFromText('POINT(10.4030 63.4281)'),
  'Bakklandet'
);
