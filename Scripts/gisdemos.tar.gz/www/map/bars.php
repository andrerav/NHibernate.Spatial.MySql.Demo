<?php

// Connection details
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'map';

$query = "SELECT JSON_APPEND(JSON_APPEND('{\"type\":\"Feature\"}', 'geometry', ST_AsGeoJSON(position)), 'properties', JSON_APPEND('{}', 'name', CONCAT('\"', name, '\"'))) AS json FROM bars GROUP BY id";

// Connect and run query
if (!($conn = new mysqli($servername, $username, $password, $database)) ||
    mysqli_connect_errno() ||
    !($stmt = $conn->prepare($query)) ||
    !($stmt->execute()) ||
    !($stmt->bind_result($geojson)) ||
    !($stmt->fetch()))
{
  print "Whoops! $conn-errno $conn-error\n";
}

// Print FeatureCollection header
print '{"type":"FeatureCollection","features":[';

print $geojson;

$num_bars = 1;
while ($stmt->fetch()) {
  print ",$geojson";
  $num_bars++;
}

print ']}';

$stmt->close();
$conn->close();

// Dump some debug info in log.html
ob_start();
print '<html><head></head><body><pre>';
print '$num_bars = '; var_dump($num_bars);
print '</pre></body></html>';
file_put_contents('log.html', ob_get_contents());
ob_end_clean();

?>

